#TODO
Set suitable media queries to allow the flexbox to resize accordingly
For mobile screens 
-> 2 columns
